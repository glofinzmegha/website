index.php
---------------------------------------------------------------------------------------
This file is used for methods testing. Run this file from console or from web browser
using the commands below:

Command Line
php run.php %method%,

%method% - define the method you need to run (for example, cart.create, product.list, etc.).

Browser
http://localhost/code_sample_php/run.php?method=%method%

%method% - define the method you need to run (for example, cart.create, product.list, etc.).

For more details visit http://docs.api2cart.com/


allViewMethod
---------------------------------------------------------------------------------------
This file contains all examples of how to use API2Cart's methods.